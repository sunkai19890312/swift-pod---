//
//  SKShareManager.swift
//  D
//
//  Created by 孙凯 on 2019/12/26.
//  Copyright © 2019 孙凯. All rights reserved.
//

import UIKit

open class SKShareManager: NSObject {
    public func register() {
        WXApi.registerApp("aaa", universalLink: "aaa");
        TencentOAuth.init(appId: "aaa", andDelegate: (self as! TencentSessionDelegate));
        WeiboSDK.registerApp("aaa")
    }
}
