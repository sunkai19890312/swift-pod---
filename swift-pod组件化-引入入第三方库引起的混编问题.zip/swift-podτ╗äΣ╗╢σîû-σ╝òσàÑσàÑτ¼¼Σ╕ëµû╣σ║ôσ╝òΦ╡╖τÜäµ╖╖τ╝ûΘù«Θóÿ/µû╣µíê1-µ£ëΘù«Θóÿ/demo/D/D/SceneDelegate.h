//
//  SceneDelegate.h
//  D
//
//  Created by 孙凯 on 2019/12/25.
//  Copyright © 2019 孙凯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

